export class Ingredient
{
    // 1. Cara Pertama
    // public name:string;
    // public amount:number;

    // constructor(name:string,amount:number)
    // {
    //     this.name=name;
    //     this.amount=amount;
    // }
    // 2. cara kedua
    constructor(public name:string, public amount:number)
    {
        
    }
}